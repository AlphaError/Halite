package hlt;

public class UndockMove extends Move {

    public UndockMove(final Ship ship) {
        super(MoveType.Undock, ship);
    }
}
